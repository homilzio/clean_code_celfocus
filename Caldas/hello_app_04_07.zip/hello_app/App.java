public class App {
	
	public static void main (String [] args){
		
		System.out.println("Args you introduced was: ");
		
		  for (int i = 0; i< args.length; ++i) {
			System.out.println("Entrei uma vez com o indice: " + i);
			String s = args[i];
			System.out.print(i + " ");
            System.out.println(s);
        }
		
		System.out.println("Hello World!");
		
		int amount = sumAmount(1, 1);
		
		System.out.println("Sum result is: " + amount);
	
	}
	
	
	private static int sumAmount(int first, int second){
		
		return first + second;
		
	}
	
	
}